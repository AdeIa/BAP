$(document).on('page:load', function(){
    $('.selectpicker').selectpicker();
});
